# PDF to Slides & Video (Generalized Visual Explanation Prototype)

Convert any PDF into:
- PPT slides
- Narrated explainer video

Run:
pip install -r requirements.txt
python run_pipeline.py --input sample.pdf --outdir output/
